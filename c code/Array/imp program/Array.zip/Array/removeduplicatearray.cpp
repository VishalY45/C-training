#include<Stdio.h>
int main()
{
	int a[5],i,j,f=-1;
	printf(" Enter array");
	for(i=0;i<5;i++)
	{
		scanf("%d",&a[i]);
	}
	printf(" before removing");
	for(i=0;i<5;i++)
	{
		printf("\na[%d]---->%d",i,a[i]);
	}
	for(i=0;i<5;i++)
	{
		for(j=i+1;j<5;j++)
		{
			if(a[i]==a[j])
			{
			 f=1;
			 a[j]=-1;
			}
		}
	}
	if(f==0)
	{
		printf("\n%d",a[i]);
	}
}