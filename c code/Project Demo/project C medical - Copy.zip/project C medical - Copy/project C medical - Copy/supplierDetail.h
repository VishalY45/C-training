struct supplier
{
	char sname[90];
	int sid;
	int smobile_no;
	char scity[20];
	char semail[20];
	
};
