struct customer
{
	char cname[90];
	int cid;
	 char ccity[90];
	int cmobile;
	char cemail[90]; 
};
