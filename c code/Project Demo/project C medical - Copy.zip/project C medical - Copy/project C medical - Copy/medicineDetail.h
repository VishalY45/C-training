struct medicine {
	char mname[90];
    char mpur_date[90];
	char mexp_date[90];
	char mmanu_date[90];
    char mcompy_name[90];
	char supp_name[90];
	int mrack;
	int mcabinate;
	int mquantity;
	int pur_price;
	int mbill_no;
		int mid;
};
