void about() {
    printf("\nAbout Medical Store Management Project\n");
    printf("This project is designed to manage medical store records.\n");
    printf("It helps store, edit, search, and delete data using file handling and data structures.\n");
    printf("Project modules include Customer Info, Medicine, Supplier Info, Billing, and more.\n");
    printf("Developed by:Soham Solat And Vishal Yadav\n");
}
