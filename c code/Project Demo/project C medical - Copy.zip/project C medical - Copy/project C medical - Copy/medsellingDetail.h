struct sell{
	char customerN[90];
	char mediN[90];
	int id;
	int mediquantity;
	int purprice;
	int sellingPrice;
	int profit;
	char datee[90];
	
};
